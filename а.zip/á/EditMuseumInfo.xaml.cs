﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace а
{
    /// <summary>
    /// Логика взаимодействия для EditMuseumInfo.xaml
    /// </summary>
    public partial class EditMuseumInfo : Window
    {
        МузейныеФондыEntities _context = new МузейныеФондыEntities();
        Авторы _авторы = new Авторы();
        MainWindow _mainWindow = new MainWindow();
        public EditMuseumInfo(МузейныеФондыEntities context, Object o, MainWindow mainWindow)
        {
            InitializeComponent();
            _context = context;
            _авторы = (o as Button).DataContext as Авторы;
            _mainWindow = mainWindow;

            ФИО.Text = _авторы.ФИО;
            Дата_рождения.SelectedDate = _авторы.Дата_рождения;
            Страна.Text = _авторы.Страна;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(_авторы.ФИО, "Хотите удалить автора?", MessageBoxButton.YesNo);
            if (result== MessageBoxResult.Yes)
            {
                _context.Авторы.Remove(_авторы);
                _context.SaveChanges();

                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            _авторы.Страна = Страна.Text;
            _авторы.Дата_рождения = Дата_рождения.SelectedDate;
            _context.SaveChanges();

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
